`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: SNX ����
// Engineer: 
// 
// Create Date: 2022/04/10 16:49:42
// Design Name: 
// Module Name: LED
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module LED(
output [3:0] led
    );
assign led = 4'hf;
endmodule
